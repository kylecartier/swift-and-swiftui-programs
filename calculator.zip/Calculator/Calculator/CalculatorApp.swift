//
//  CalculatorApp.swift
//  Calculator
//
//  Created by Kyle Cartier on 3/20/25.
//

import SwiftUI

@main
struct CalculatorApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
