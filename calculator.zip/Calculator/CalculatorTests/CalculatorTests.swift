//
//  CalculatorTests.swift
//  CalculatorTests
//
//  Created by Kyle Cartier on 3/20/25.
//

import Testing
@testable import Calculator

struct CalculatorTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
